


You have to submit 3 independent files with EXACTLY the following names (NO zip, etc.).

horaris.pl
tsp.pl
latin.pl



horaris.pl:

Modify your horaris.pl class exercise solution as follows
(or re-do from scratch from the original exercise horaris.pl given here):
Instead of minimizing the number of professors, now
find a schedule that minimizes the number of years that
have some course being taught in the morning, i.e. a course having
a lecture that starts some time between 8 and 14  (14 inclusive).



tsp.pl:

Modify the tsp predicate (not main or any other predicate) in order
to do a full cycle, returning to city 1.
For N=11 it should write: Optimal route: [1,5,4,11,7,3,10,8,2,6,9,1]. 612 km.
No need to optimize your code.



latin.pl:

Complete as indicated in the source file.




